"use client";
import { useEffect, useState } from "react";
import {
  getNotifications,
  markAllNotificationsRead,
  markNotificationRead,
  Notification,
} from "@/lib/api/notifications";
export default function NotificationsPage() {
  const [items, setItems] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const load = () => {
    setLoading(true);
    getNotifications()
      .then((r) => setItems(r.items))
      .catch(() => setItems([]))
      .finally(() => setLoading(false));
  };
  useEffect(load, []);
  return (
    <div className="mx-auto max-w-4xl">
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-bold uppercase tracking-[.2em] text-primary">Account</p>
          <h1 className="mt-1 text-3xl font-black">Notifications</h1>
          <p className="mt-2 text-sm text-muted">
            Order updates, promotions, seller news and account alerts.
          </p>
        </div>
        <button
          onClick={() => markAllNotificationsRead().then(load)}
          className="rounded-xl border border-border bg-surface px-4 py-2.5 text-sm font-bold"
        >
          Mark all read
        </button>
      </div>
      <div className="grid gap-3">
        {loading ? (
          <div className="rounded-2xl border border-border bg-surface p-8 text-center text-muted">
            Loading notifications…
          </div>
        ) : items.length === 0 ? (
          <div className="rounded-2xl border border-border bg-surface p-8 text-center text-muted">
            You are all caught up.
          </div>
        ) : (
          items.map((n) => (
            <div
              key={n.id}
              className={`rounded-2xl border p-4 ${n.isRead ? "border-border bg-surface" : "border-primary/30 bg-primary/5"}`}
            >
              <div className="flex gap-3">
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary/10">
                  🔔
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-col gap-1 sm:flex-row sm:justify-between">
                    <h2 className="font-bold">{n.title}</h2>
                    <span className="text-[11px] text-muted">
                      {new Date(n.createdAt).toLocaleString()}
                    </span>
                  </div>
                  <p className="mt-1 text-sm text-muted">{n.message}</p>
                  {!n.isRead && (
                    <button
                      onClick={() => markNotificationRead(n.id).then(load)}
                      className="mt-3 text-xs font-bold text-primary"
                    >
                      Mark as read
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
